const config = require("../../botconfig/config.json")
var ee = require("../../botconfig/embed.json")
module.exports = {
	//definition
	name: "setpoints",
	category: "📈 Ranking",
	aliases: [""],
	cooldown: 4,
	usage: "setpoints <@User> <Amount>",
  	description: "Set a specific amount of Points to a User",

	  
  run: async (client, message, args, user, text, prefix) => {

	}
}